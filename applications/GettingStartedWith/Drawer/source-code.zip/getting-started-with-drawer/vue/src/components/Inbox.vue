<template>
    <div>Inbox</div>
</template>

<script>
export default {};
</script>