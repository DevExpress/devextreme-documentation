<template>
    <DxList
        :width="200"
        selection-mode="single"
        :items="navigation"
        @selection-changed="loadView($event)"
    />
</template>
<script>
import { DxList } from "devextreme-vue/list";

export default {
    components: {
        DxList
    },
    data() {
        const navigation = [
            { id: 1, text: "Inbox", icon: "message", filePath: "inbox" },
            { id: 2, text: "Sent Mail", icon: "check", filePath: "sent-mail" },
            { id: 3, text: "Trash", icon: "trash", filePath: "trash" },
            { id: 4, text: "Spam", icon: "mention", filePath: "spam" }
        ];
        return {
            navigation
        };
    },
    methods: {
        loadView(e) {
            this.$router.push(e.addedItems[0].filePath);
            this.$emit('navigated', true);
        }
    }
};
</script>