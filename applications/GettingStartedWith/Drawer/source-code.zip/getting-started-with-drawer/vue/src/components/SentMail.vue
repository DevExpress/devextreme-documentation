<template>
    <div>Sent mail</div>
</template>

<script>
export default {};
</script>