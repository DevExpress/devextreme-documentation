<template>
    <div>Spam</div>
</template>

<script>
export default {}
</script>