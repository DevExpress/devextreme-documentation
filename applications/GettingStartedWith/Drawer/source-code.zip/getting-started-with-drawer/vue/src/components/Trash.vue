<template>
    <div>Trash</div>
</template>

<script>
export default {}
</script>